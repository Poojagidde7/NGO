<?php
$amount = $_POST['amount'];
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$email = $_POST['email'];


//database connection
$conn = new mysqli('localhost', 'root','','project');
if($conn->connect_error){
    die('Connection failed : '.$conn->connect_error);
}else{
    $stmt = $conn->prepare("insert into donate(amount, firstName, lastName, email) values(?, ?, ?, ?)");
    $stmt->bind_param("isss", $amount, $firstName, $lastName, $email);
    $stmt->execute();
    echo "Thanks For Donating";
    $stmt->close();
    $conn->close();
}

?>