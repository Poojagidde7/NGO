<?php
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database_name";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind SQL statement
$stmt = $conn->prepare("INSERT INTO donations (amount, firstName, lastName, email, zip) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $amount, $firstName, $lastName, $email, $zip);

// Set parameters and execute
$amount = $_POST['amount'];
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$email = $_POST['email'];
$zip = $_POST['zip'];
$stmt->execute();

echo "Thank you for your donation!";

$stmt->close();
$conn->close();
?>