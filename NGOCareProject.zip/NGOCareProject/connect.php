<?php
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];


//database connection
$conn = new mysqli('localhost', 'root','','project');
if($conn->connect_error){
    die('Connection failed : '.$conn->connect_error);
}else{
    $stmt = $conn->prepare("insert into volunteer(name, email, message) values(?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $message);
    $stmt->execute();
    echo "Your data has been successfully submitted.We will get back to you shortly.";
    $stmt->close();
    $conn->close();
}

?>